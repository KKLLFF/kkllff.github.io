{include admin header}
{if $html}{$html}{else}<h3 class="center">404</h3>{/if}
{include admin footer}