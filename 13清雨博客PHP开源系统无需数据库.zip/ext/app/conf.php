<?php
return array (
	'id' => 'app',
	'type' => 'ext',
	'author' => '雪洛',
	'name' => '应用中心',
	'intro' => '官方应用中心，提供主题模板、扩展的更新与安装。',
	'price' => 0,
	'home' => 'https://xhnzz.com',
	'version' => '1.0.7',
	'limit' => '1.0.0',
);
?>