<?php
hook('editor','<link rel="stylesheet" href="'.HOME.'ext/fk-editor/fk.css"/><script src="'.HOME.'ext/fk-editor/fk.js"></script><script>SX.fkEditor("#content");</script>');
?>