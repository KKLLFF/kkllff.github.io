<?php
return array (
	'id' => 'fk-editor',
	'type' => 'ext',
	'author' => '雪洛',
	'name' => 'fk标记语言编辑器',
	'intro' => 'fkEditor是一款简洁高效的fk标记语言编辑器，拥有高效便捷的快捷键，支持图片、附件上传。',
	'price' => 0,
	'home' => 'https://xhnzz.com',
	'version' => '1.0.6',
	'limit' => '1.0.0'
);
?>