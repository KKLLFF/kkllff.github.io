<?php
return array (
  'title' => '',
  'name' => '',
  'intro' => '',
  'mood' => '夜露黏寒，层云弄影，烛映帘栊月半弯',
  'key' => '',
  'desc' => '',
  'brief' => 40,
  'avatar' => '/lib/style/logo.svg',
  'username' => '清雨',
  'password' => '',
  'tpl' => 'default',
  'compile' => true,
  'debug' => 2,
  'rewrite' => false,
  'article' => 
  array (
    'paging' => 30,
    'count' => 2,
  ),
  'comment' => 
  array (
    'restrict' => 20,
    'paging' => 30,
    'count' => 0,
  ),
  'thumb' => 
  array (
    'open' => true,
    'width' => 300,
    'height' => 300,
    'type' => 1,
  ),
  'vcode' => 
  array (
    'open' => true,
    'width' => 86,
    'height' => 28,
    'length' => 4,
  ),
  'icp' => '',
  'prn' => '',
  'views' => 0,
  'blacklist' => '',
  'tag' => 
  array (
    '默认' => 2,
  ),
  'ext' => 
  array (
    'app'=>1,
    'fk-editor'=>1,
  ),
  'category' => 
  array (
    'default' => 
    array (
      'id' => 'default',
      'name' => '默认',
      'intro' => '官网默认',
      'count' => 2,
    ),
  ),
  'navbar' => 
  array (
    0 => 
    array (
      'name' => '首页',
      'url' => '/',
      'target' => 0,
      'child' => 
      array (
      ),
    ),
    1 => 
    array (
      'name' => '留言',
      'url' => '/?message',
      'target' => 0,
      'child' => 
      array (
      ),
    ),
  ),
  'link' => 
  array (
    0 => 
    array (
      'name' => '关于本站',
      'url' => '/?about',
      'target' => 0,
    ),
  ),
  'js' => '',
  'install' => false,
  'db' => 
  array (
    'version' => '1.1.0',
  ),
);
?>